# Heroku তে হোস্ট করতে যা যা করতে হবে আপনাকে।

1. এই "server" folder টি কপি করে আলাদা জায়গায় নিয়ে যান।
2. আপনার গিটহাবে আপ্লোড করুন এই কোড গুলো।
3. [Heroku](https://dashboard.heroku.com/) তে গিয়ে নতুন প্রজেক্ট তৈরি করুন।
4. Deployment method এ Github নির্বাচন করুন।
5. আপনার ব্রাঞ্চ সিলেক্ট করুন।
6. Deploy branch এ ক্লিক করে ডেপ্লয় করুন।
7. না বুঝতে পারলে এই ভিডিওটি দেখুন - https://learnwithsumit.com/courses/think-in-a-redux-way/how-to-deploy-server-to-heroku
